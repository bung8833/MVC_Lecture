﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjFFoodPandaApp
{
    internal class CGame
    {
        public int fId { get; set; } 
        public string? fName { get; set; }
        public int? fQty { get; set; }
        public decimal? fCost { get; set; }
        public decimal? fPrice { get; set; }
    }
}
